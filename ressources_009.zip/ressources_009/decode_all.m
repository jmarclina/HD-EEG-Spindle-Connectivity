function [Classe] = decode_all(chemins)
Classe.Table = [];
OK = 0;
fprintf('\n -- Decodage (Nuit,Cycle,Stade) ... ');
for i = 1:numel(chemins)
    [a,b,c,err] = decodage(chemins(i).chemin);
    Classe.K(i).Night = a;
    Classe.K(i).Cycle = b;
    Classe.K(i).Stade = c;
    Classe.Table(i,:) = [a b c];
    OK = OK+err;
end
Classe.Comment = 'Night, Cycle, Stade';
if err, fprintf(' ! Erreur de decodage Nuit/Cycle/Stade\n'); 
else
    fprintf(' done\n');
    % nombre de nuits
    Nn = unique(Classe.Table(:,1))'; Nbn = numel(Nn);
    fprintf('\n     . Il y a %d nuit(s):',Nbn);
    for i=1:Nbn
        fprintf('\n       > Nuit %d:',Nn(i));
        Nuit{i} = Classe.Table(Classe.Table(:,1)==Nn(i),2:3);
        Cy = unique(Nuit{i}(:,1))'; Nbc = numel(Cy);
        for j=1:Nbc
            Cyj = Nuit{i}(Nuit{i}(:,1)==Cy(j),2);
            St2 = sum(Cyj==2);
            St3 = sum(Cyj==3);
            fprintf('\n       %d segments (Cycle %d, stade 2)',St2,Cy(j));
            fprintf('\n       %d segments (Cycle %d, stade 3)',St3,Cy(j));
        Selection{i,j,1} = []; 
        Selection{i,j,2} = find(Classe.Table(:,1)==Nn(i)&...
                                Classe.Table(:,2)==Cy(j)&...
                                Classe.Table(:,3)==2);
        Selection{i,j,3} = find(Classe.Table(:,1)==Nn(i)&...
                                Classe.Table(:,2)==Cy(j)&...
                                Classe.Table(:,3)==3);
        end
        fprintf('\n');
    end
    Classe.Selection = Selection;
end
end