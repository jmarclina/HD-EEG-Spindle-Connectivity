


addpath(genpath('./brainstorm3'))
% Repertoire qui contient le materiel de la base de données de Brainstorm
addpath(genpath('./HModel'))


clear; clc
load('headmodel_surf_openmeeg.mat','Gain','GridOrient')
Gain = bst_gain_orient(Gain, GridOrient, []);

%%% Canaux retenus:
load('channel_GSN_HydroCel_256_E1.mat','Channel');
Reject = find(isnan(Gain(:,1)));
Keep   = find(~isnan(Gain(:,1)));
EEG_G = Gain(Keep,:);

%%% Atals retenu:
load('tess_cortex_pial_low_8000V.mat','Atlas')
Atlas = Atlas(3);

%%% Espace source retenu:
load('tess_cortex_pial_low_8000V.mat','Faces','Vertices','VertConn')
cortex.Faces = Faces;
cortex.VertConn = VertConn;
cortex.Vertices = Vertices;

if ~exist('./Workspaces','dir'); mkdir('./Workspaces'); end
save('./Workspaces/Workspace_HModel','cortex','EEG_G','Atlas')
