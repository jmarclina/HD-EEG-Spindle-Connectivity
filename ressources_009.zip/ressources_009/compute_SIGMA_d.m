function CovD = compute_SIGMA_d(data)
    % Partie reelle:
    dataR = real(data);
    baseline = surrogate_baseline(dataR);
    baseline = baseline-mean(baseline,2);
    CR = 1/size(baseline,1) * baseline*baseline';
    % Partie imaginaire:
    dataI = imag(data);
    baseline = surrogate_baseline(dataI);
    baseline = baseline-mean(baseline,2);
    CI = 1/size(baseline,1) * baseline*baseline';
    % Surrogate:
    for I = 1:64
        baseline = surrogate_baseline(dataR);
        baseline = baseline-mean(baseline,2);
        CR = ((I-1)*CR + 1/size(baseline,1) * baseline*baseline')/I;
        baseline = surrogate_baseline(dataI);
        baseline = baseline-mean(baseline,2);
        CI = ((I-1)*CI + 1/size(baseline,1) * baseline*baseline')/I;
    end
    CovD.Creal = CR;
    CovD.Cimag = CI;

end