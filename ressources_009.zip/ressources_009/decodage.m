function [Nuit,Cycle,Stade,err] = decodage(chemin)
% chemin <-- INVENTAIRE_SPDL.source(1).chemin
    err = 0;
    Nuit = [];
    U = strsplit(chemin,'_Night');
    U = strsplit(U{end},'_');
    Nuit = str2num(U{1});
    
    Cycle = [];
    U = strsplit(chemin,'_Cycle');
    U = strsplit(U{end},'_');
    Cycle = str2num(U{1});
    
    Stade = [];
    U = strsplit(chemin,'_N');
    U = strsplit(U{end},'.mat');
    Stade = str2num(U{1});
    
    if isempty(Nuit)||isempty(Cycle)||isempty(Stade), err = 1;end

end