function LUTi = find_electrodes(LUT,Canaux)
    % recherche des canaux LUT dans les canaux
    % du systeme
    S = zeros(1,numel(Canaux));
    R = zeros(1,numel(LUT));
    for i = 1:numel(LUT)
        e = LUT{i};
        y = strcmpi(Canaux,e);
        if sum(y)==1
            S(y==1) = 1;
            R(i) = 1;
            else
            fprintf('\n !- probleme avec %s',e);
            R(i) = -1;
        end
    end
    NR = find(R==-1);
    for i = 1:numel(NR)
        a = strfind(LUT{NR(i)},'(');
        b = strfind(LUT{NR(i)},')');
        e = LUT{NR(i)}(a+1:b-1);
        y = strcmpi(Canaux,e);
        if sum(y)==1
            S(y==1) = 1;
            R(NR(i)) = 1;
            fprintf('\n -- probleme %s resolu',e);
            else
            fprintf('\n !- tj probleme avec %s',e);
            R(NR(i)) = -1;
        end
    end
    fprintf('\n');
    LUTi = find(S==1);
end