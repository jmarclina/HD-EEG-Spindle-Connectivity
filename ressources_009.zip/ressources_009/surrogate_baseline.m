function y = surrogate_baseline(x)
% x: Nc x Nt signals
    [Nc,Nt] = size(x);
    x = x';
    u = randperm(Nt);
    xf = fft(x);
    ph = (0:Nt-1)*(2*pi/Nt).*u;
    u  = exp(-1i*ph');
    xs = repmat(u,1,Nc) .* xf;
    y  = ifft(xs,'symmetric');
    y = (y - mean(y,1))';
end
    