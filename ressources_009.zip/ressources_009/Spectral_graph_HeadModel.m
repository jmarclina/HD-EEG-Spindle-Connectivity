function model = Spectral_graph_HeadModel(cortex,EEG_G)

% taille initiale du probleme:
[~,Ns] = size(EEG_G);
% laplacien:
Adj = full(cortex.VertConn);
Edg = sum(Adj,2);
Lap = diag(Edg) - Adj;
% Analyse spectrale:
fprintf('\n -- Spectral Graph Analysis ...')
[Q1,L,~] = svd(Lap);
fprintf(' done.');
% Frequence et modes (graphical model)
L = diag(L);
[~,b] = sort(L,'ascend');
L  = L(b);
Qi = Q1(:,b);
% Gain par mode de Fourier (graph)
for i=1:Ns
    P(i).mode = L(i);
    P(i).gain = EEG_G * Qi(:,i);
end

% Selection optimale: on compare les conditionnements avec le
% conditionnment de G*G'
Kmax = cond(EEG_G*EEG_G');

% Selection des modes: le critère est le conditionnement de la matrice (à
% inverser) Gi*Gi'
% Approche itérative (et non optimale) en incrementant les modes qui
% assurent un conditionnement le plus petit possible
% 1er choix
K = []; Ap = []; Bp = [];
for i = 1:Ns, K(i) = cond(P(i).gain * P(i).gain'); end
[b,a]=min(K); UP = P(a).gain * P(a).gain';
Ap(1) = a;
Bp(1) = b;
% ne regarde que les 250 premieres iterations
Ni = 250; j = 1;
while Bp(j)>Kmax && j<Ni
    bprev = b;
    fprintf(['\n -- ' num2str(j) '/' num2str(Ni) ' -->'])
    Us = setdiff(1:Ns,Ap);
    K  = [];
    for i = 1:numel(Us), K(i) = cond(UP + P(Us(i)).gain * P(Us(i)).gain'); end
    [b,a]=min(K);
    Ap(j+1) = Us(a);
    Bp(j+1) = b;
    UP = UP + P(Us(a)).gain * P(Us(a)).gain';
    fprintf(' K = %4.2e (%3.1f %%)',b,100*(b-bprev)/bprev);
    j = j+1;
end

% modes selectionnes
model.selection = unique(Ap);
model.modes = Qi(:,model.selection);
% frequences (graphe) selectionnees
model.spectre   = L(model.selection);
% matrice de Gain reduite et aussi bien conditionnée que l'original:
model.EEG_G = [];
for i=1:numel(model.selection), model.EEG_G(:,i) = P(model.selection(i)).gain; end
end