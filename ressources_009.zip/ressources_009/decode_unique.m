function [Classe] = decode_unique(chemins)
Classe.Table = [];

fprintf('\n -- Decoding ... ');

    [a,b,c,OK] = decodage(chemins.chemin);
    Classe.Night = a;
    Classe.Cycle = b;
    Classe.Stade = c;
    Classe.Table = [a b c];
    Classe.type = ['Ni' num2str(a) 'Cy' num2str(b) 'St' num2str(c)];

Classe.Comment = 'Night, Cycle, Stage';

if OK, fprintf(' ! Erreur du decodage Nuit/Cycle/Stade\n'); 
else
        fprintf(' Night %d:',a);
        fprintf(' Cycle %d, stage %d\n', b, c);
end
end